const showTheWay = () => {
    console.log('Run Boy Run');
  };
  