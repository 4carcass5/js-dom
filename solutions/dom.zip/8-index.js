import app from './8-events.js';

app();